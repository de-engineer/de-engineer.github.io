---
title: About
icon: fas fa-info
order: 4
---

Hey, Mr. Rc here.
I am a learner.
I have interest in bug bounties, reverse engineering, coding, security ctfs and much more.

Also, If you are here for OSINT, I am not that dumb that I will reveal my identity here.
